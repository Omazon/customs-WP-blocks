<?php
$quote = get_field('quote')?:"Escribe el quote";
?>
<blockquote><p><?= $quote ?></p></blockquote>
