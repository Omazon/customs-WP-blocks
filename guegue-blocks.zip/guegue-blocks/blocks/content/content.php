<?php
$contenido = get_field('contenido')?:'Escribe el contenido de este bloque';
?>
<?= $contenido ?>

