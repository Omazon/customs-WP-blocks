<?php
$inserte_html = get_field('inserte_html')?:'<pre>Inserte el html</pre>';
?>

<div class="container">
    <div class="entry-featured wp-caption ratio ratio-16x9 mb-4 mb-lg-9">
        <?= $inserte_html ?>
    </div>
</div>
