<?php while (have_posts()) : the_post(); ?>
<article class="entry g-lg-4 mb-6 mb-lg-10">
    <?php the_content(); ?>
</article>
<?php endwhile; ?>
